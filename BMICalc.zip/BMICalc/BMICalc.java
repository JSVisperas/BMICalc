import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class BMICalc extends JFrame
{
    JLabel height = new JLabel();
    JLabel weight = new JLabel();
    JLabel bmi = new JLabel();
    JLabel height1 = new JLabel();
    JLabel height2 = new JLabel();
    JLabel weight1 = new JLabel();
    
    JTextField feet = new JTextField();
    JTextField inches = new JTextField();
    JTextField pounds = new JTextField();
    JTextField bmiRes = new JTextField();
    
    JButton computeBmi = new JButton();
    JButton clear = new JButton();
    JButton exit = new JButton();
    
    public BMICalc()
    {
        setTitle("BMI Calculator");
        setSize(400, 200);
        getContentPane().setLayout(new GridBagLayout());
        GridBagConstraints gridCons = new GridBagConstraints();
        
        height.setText("Height: ");
        gridCons.gridx = 0;
        gridCons.gridy = 0;
        getContentPane().add(height, gridCons);
        
        feet.setText("");
        feet.setColumns(4);
        gridCons.gridx = 1;
        gridCons.gridy = 0;
        getContentPane().add(feet, gridCons);
        
        height1.setText(" (feet) ");
        gridCons.gridx = 2;
        gridCons.gridy = 0;
        getContentPane().add(height1, gridCons);
        
        inches.setText("");
        inches.setColumns(4);
        gridCons.gridx = 3;
        gridCons.gridy = 0;
        getContentPane().add(inches, gridCons);
        
        height2.setText(" (inches) ");
        gridCons.gridx = 4;
        gridCons.gridy = 0;
        getContentPane().add(height2, gridCons);
        
        weight.setText("Weight: ");
        gridCons.gridx = 0;
        gridCons.gridy = 1;
        getContentPane().add(weight, gridCons);
        
        pounds.setText("");
        pounds.setColumns(4);
        gridCons.gridx = 1;
        gridCons.gridy = 1;
        getContentPane().add(pounds, gridCons);
        
        weight1.setText("(pounds) ");
        gridCons.gridx = 2;
        gridCons.gridy = 1;
        getContentPane().add(weight1, gridCons);
        
        bmi.setText("BMI: ");
        gridCons.gridx = 0;
        gridCons.gridy = 2;
        getContentPane().add(bmi, gridCons);
        
        bmiRes.setText(" ");
        bmiRes.setColumns(6);
        gridCons.gridx = 1;
        gridCons.gridy = 2;
        getContentPane().add(bmiRes, gridCons);
        
        computeBmi.setText("Compute BMI");
        gridCons.gridx = 0;
        gridCons.gridy = 3;
        getContentPane().add(computeBmi, gridCons);
        
        computeBmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                compBmi(e);
            }
        });
        
        clear.setText("Clear");
        gridCons.gridx = 2;
        gridCons.gridy = 3;
        getContentPane().add(clear, gridCons);
        
        clear.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                clearCalc(e);
            }
        });
        
        exit.setText("Exit");
        gridCons.gridx = 4;
        gridCons.gridy = 3;
        getContentPane().add(exit, gridCons);
        
        exit.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                exitapp(e);
            }
        });
        
        
    }
    public static void main(String []args){
        new BMICalc().show();
    }
    public void compBmi(ActionEvent e){
        String a = feet.getText();
        String b = inches.getText();
        String c = pounds.getText();
        float num1 = Float.parseFloat(a);
        float num2 = Float.parseFloat(b);
        float num3 = Float.parseFloat(c);
        
        float inch = num1 * 12;
        float inch2 = inch + num2;
        float res = (num3 / (inch2 * inch2)) * 703;
        String result = Float.toString(res);
        
        bmiRes.setText(result);
        
    }
    public void clearCalc(ActionEvent e){
        feet.setText("");
        inches.setText("");
        pounds.setText("");
        bmiRes.setText("");
    }
    public void exitapp(ActionEvent e){
        System.exit(0);
    }
}
